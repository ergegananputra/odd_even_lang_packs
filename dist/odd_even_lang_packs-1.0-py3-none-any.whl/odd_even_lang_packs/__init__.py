from .main import OddEvenLangPacks

__all__ = ['OddEvenLangPacks']